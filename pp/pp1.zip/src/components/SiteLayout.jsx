import { useEffect } from 'react';

import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';

import NeuralBackground from './NeuralBackground';

const navItems = [
  { label: 'Landing', to: '/' },
  { label: 'Home', to: '/home' },
  { label: 'Projects', to: '/projects' },
  { label: 'About', to: '/about' },
  { label: 'Contact', to: '/contact' },
];

function SiteLayout() {
  const location = useLocation();
  const isLandingPage = location.pathname === '/';

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <div className="app-shell">
      <NeuralBackground className="app-background" />

      <div className="app-frame">
        {!isLandingPage ? (
          <header className="site-header">
            <Link className="site-brand" to="/">
              <span className="panel-dot" />
              Pavan Kumar
            </Link>

            <nav className="site-nav" aria-label="Primary navigation">
              {navItems.map((item) => (
                <NavLink
                  key={item.label}
                  to={item.to}
                  end={item.to === '/'}
                  className={({ isActive }) =>
                    isActive ? 'site-nav-link site-nav-link-active' : 'site-nav-link'
                  }
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>
          </header>
        ) : null}

        <main className={isLandingPage ? 'landing-route-shell' : 'content-shell route-shell'}>
          <Outlet />
        </main>

        {!isLandingPage ? (
          <footer className="site-footer">
            <span>Built for Pavan Kumar’s portfolio in React.</span>
            <span>
              <a href="mailto:pavankumargp88@gmail.com">pavankumargp88@gmail.com</a>
            </span>
          </footer>
        ) : null}
      </div>
    </div>
  );
}

export default SiteLayout;