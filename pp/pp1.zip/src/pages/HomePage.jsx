import { Link } from 'react-router-dom';

function HomePage() {
  return (
    <>
      <section className="section-block">
        <div className="section-heading">
          <div>
            <div className="section-label">Home</div>
            <h2>Portfolio overview</h2>
          </div>
        </div>

        <div className="section-grid home-grid">
          <article className="section-card section-card-large">
            <div className="section-label">About</div>
            <h2>Where the work is heading</h2>
            <p>
              I enjoy building systems that combine strong logic with useful interfaces. My
              current direction is toward applied AI, medical imaging, database systems, and
              modern frontend experiences that feel polished and interactive.
            </p>
          </article>

          <article className="section-card">
            <div className="section-label">Location</div>
            <h3>Shahabad, Karnataka</h3>
            <p>Home base and the place that shaped my academic and technical journey.</p>
          </article>

          <article className="section-card">
            <div className="section-label">Email</div>
            <h3>Pavan Kumar</h3>
            <p>pavankumargp88@gmail.com</p>
          </article>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div>
            <div className="section-label">Quick Links</div>
            <h2>Jump to the rest of the portfolio</h2>
          </div>
        </div>

        <div className="project-grid">
          <Link className="project-card home-link-card" to="/projects">
            <div className="project-topline">
              <span>Projects</span>
              <span>Selected work</span>
            </div>
            <h3>Open the project gallery</h3>
            <p>See the AI, DBMS, and web systems that make up the portfolio.</p>
          </Link>

          <Link className="project-card home-link-card" to="/about">
            <div className="project-topline">
              <span>About</span>
              <span>Education and skills</span>
            </div>
            <h3>Read the background</h3>
            <p>Review education, technical strengths, and notable milestones.</p>
          </Link>

          <Link className="project-card home-link-card" to="/contact">
            <div className="project-topline">
              <span>Contact</span>
              <span>Reach out</span>
            </div>
            <h3>Open contact details</h3>
            <p>Use email, LinkedIn, or GitHub to continue the conversation.</p>
          </Link>

          <article className="project-card">
            <div className="project-topline">
              <span>Current focus</span>
              <span>Applied AI</span>
            </div>
            <h3>Deep learning and interactive systems</h3>
            <p>Current work centers on segmentation, automation, and polished frontend delivery.</p>
          </article>
        </div>
      </section>
    </>
  );
}

export default HomePage;