import { achievements, education, skills } from '../data/portfolioData';

function AboutPage() {
  return (
    <>
      <section className="section-block">
        <div className="section-heading">
          <div>
            <div className="section-label">About</div>
            <h2>Where the work is heading</h2>
          </div>
        </div>

        <article className="section-card section-card-large">
          <p>
            I enjoy building systems that combine strong logic with useful interfaces. My current
            direction is toward applied AI, medical imaging, database systems, and modern frontend
            experiences that feel polished and interactive.
          </p>
        </article>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div>
            <div className="section-label">Education</div>
            <h2>Academic background</h2>
          </div>
        </div>

        <div className="card-list">
          {education.map((item) => (
            <article key={item.school} className="detail-card">
              <h3>{item.school}</h3>
              <p className="detail-meta">{item.place}</p>
              <p>{item.degree}</p>
              <span>{item.meta}</span>
            </article>
          ))}
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div>
            <div className="section-label">Technical Skills</div>
            <h2>Languages, frameworks, tools, strengths</h2>
          </div>
        </div>

        <div className="skills-grid">
          <article className="skill-card">
            <h3>Languages</h3>
            <p>{skills.languages.join(' · ')}</p>
          </article>
          <article className="skill-card">
            <h3>Frameworks / Libraries</h3>
            <p>{skills.frameworks.join(' · ')}</p>
          </article>
          <article className="skill-card">
            <h3>Tools</h3>
            <p>{skills.tools.join(' · ')}</p>
          </article>
          <article className="skill-card">
            <h3>Core Strengths</h3>
            <p>{skills.strengths.join(' · ')}</p>
          </article>
        </div>
      </section>

      <section className="section-block">
        <div className="section-heading">
          <div>
            <div className="section-label">Achievements</div>
            <h2>Notable milestones</h2>
          </div>
        </div>

        <div className="achievement-list">
          {achievements.map((achievement) => (
            <div key={achievement} className="achievement-item">
              {achievement}
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

export default AboutPage;