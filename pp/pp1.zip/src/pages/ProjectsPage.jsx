import FeatureShowcase from '../components/FeatureShowcase';

import { projects } from '../data/portfolioData';

function ProjectsPage() {
  return (
    <>
      <section className="section-block">
        <div className="section-heading">
          <div>
            <div className="section-label">Projects</div>
            <h2>Selected work</h2>
          </div>
        </div>

        <p className="page-intro">
          A mix of applied AI, database-backed systems, and portfolio-style web work.
        </p>
      </section>

      <FeatureShowcase />

      <section className="section-block">
        <div className="project-grid">
          {projects.map((project) => (
            <article key={project.name} className="project-card">
              <div className="project-topline">
                <span>{project.status}</span>
                <span>{project.technologies}</span>
              </div>
              <h3>{project.name}</h3>
              <p>{project.description}</p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}

export default ProjectsPage;