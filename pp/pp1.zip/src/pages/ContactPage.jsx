import { contactLinks } from '../data/portfolioData';

function ContactPage() {
  return (
    <section className="section-block contact-page" id="contact-page">
      <div className="section-heading">
        <div>
          <div className="section-label">Contact</div>
          <h2>Let’s build the next version of this portfolio</h2>
        </div>
      </div>

      <div className="contact-block">
        <div>
          <p>
            The layout is ready for future 3D sections, motion-heavy project showcases, and
            personalized content updates.
          </p>
        </div>

        <div className="contact-actions">
          <a className="hero-button hero-button-primary" href="mailto:pavankumargp88@gmail.com">
            Email Pavan
          </a>
          <a
            className="hero-button hero-button-secondary"
            href="https://github.com/pavankumargp8"
            target="_blank"
            rel="noreferrer"
          >
            GitHub Profile
          </a>
        </div>
      </div>

      <div className="contact-grid contact-grid-wide">
        {contactLinks.map((item) => (
          <a key={item.label} className="contact-card" href={item.href} target="_blank" rel="noreferrer">
            <span>{item.label}</span>
            <strong>{item.value}</strong>
          </a>
        ))}
      </div>
    </section>
  );
}

export default ContactPage;