import { useEffect, useMemo, useRef, useState } from 'react';

import { ChevronDown, Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';

import './LandingPage.css';

function BlurText({ text, delay = 50, animateBy = 'words', direction = 'top', className = '', style }) {
  const [inView, setInView] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = ref.current;

    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
      observer.disconnect();
    };
  }, []);

  const segments = useMemo(
    () => (animateBy === 'words' ? text.split(' ') : text.split('')),
    [text, animateBy]
  );

  return (
    <p ref={ref} className={`landing-blur-text ${className}`.trim()} style={style}>
      {segments.map((segment, index) => (
        <span
          key={`${segment}-${index}`}
          style={{
            display: 'inline-block',
            filter: inView ? 'blur(0px)' : 'blur(10px)',
            opacity: inView ? 1 : 0,
            transform: inView ? 'translateY(0)' : `translateY(${direction === 'top' ? '-20px' : '20px'})`,
            transition: `all 0.5s ease-out ${index * delay}ms`,
          }}
        >
          {segment}
          {animateBy === 'words' && index < segments.length - 1 ? '\u00A0' : ''}
        </span>
      ))}
    </p>
  );
}

function LandingPage() {
  const [isDark, setIsDark] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const buttonRef = useRef(null);
  const accentColor = '#020617';
  const mutedAccentColor = '#020617';

  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        isMenuOpen &&
        menuRef.current &&
        buttonRef.current &&
        !menuRef.current.contains(event.target) &&
        !buttonRef.current.contains(event.target)
      ) {
        setIsMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMenuOpen]);

  const toggleTheme = () => {
    const nextTheme = !isDark;
    setIsDark(nextTheme);

    if (nextTheme) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const menuItems = [
    { label: 'HOME', href: '/home', highlight: true },
    { label: 'ABOUT', href: '/about' },
    { label: 'PROJECTS', href: '/projects' },
    { label: 'EXPERIENCE', href: '/about' },
    { label: 'EDUCATION', href: '/about' },
    { label: 'WRITING', href: '/projects' },
    { label: 'CONTACT', href: '/contact' },
  ];

  return (
    <div
      className="landing-page"
      style={{
        backgroundColor: isDark ? 'hsl(0 0% 0%)' : 'hsl(0 0% 98%)',
        color: isDark ? 'hsl(0 0% 100%)' : 'hsl(0 0% 10%)',
      }}
    >
      <header className="landing-header">
        <nav className="landing-nav">
          <div className="landing-menu-wrap">
            <button
              ref={buttonRef}
              type="button"
              className="landing-icon-button"
              aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="landing-icon" strokeWidth={2} />
              ) : (
                <Menu className="landing-icon" strokeWidth={2} />
              )}
            </button>

            {isMenuOpen ? (
              <div
                ref={menuRef}
                className="landing-menu"
                style={{ backgroundColor: isDark ? 'hsl(0 0% 0%)' : 'hsl(0 0% 98%)' }}
              >
                {menuItems.map((item) => (
                  <Link
                    key={item.label}
                    to={item.href}
                    className="landing-menu-link"
                    style={{
                      color: item.highlight ? '#C3E41D' : isDark ? 'hsl(0 0% 100%)' : 'hsl(0 0% 10%)',
                    }}
                    onMouseEnter={(event) => {
                      event.currentTarget.style.color = '#C3E41D';
                    }}
                    onMouseLeave={(event) => {
                      event.currentTarget.style.color = item.highlight
                        ? '#C3E41D'
                        : isDark
                          ? 'hsl(0 0% 100%)'
                          : 'hsl(0 0% 10%)';
                    }}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
            ) : null}
          </div>

          <div
            className="landing-signature"
            style={{ color: isDark ? 'hsl(0 0% 100%)' : 'hsl(0 0% 10%)' }}
          >
            PK
          </div>

          <button
            type="button"
            onClick={toggleTheme}
            className="landing-theme-toggle"
            style={{ backgroundColor: isDark ? 'hsl(0 0% 15%)' : 'hsl(0 0% 90%)' }}
            aria-label="Toggle theme"
          >
            <span
              className="landing-theme-toggle-thumb"
              style={{
                backgroundColor: isDark ? 'hsl(0 0% 100%)' : 'hsl(0 0% 10%)',
                transform: isDark ? 'translateX(2rem)' : 'translateX(0)',
              }}
            />
          </button>
        </nav>
      </header>

      <main className="landing-main">
        <div className="landing-center-copy">
          <div className="landing-center-name">
            <BlurText
              text="PAVAN"
              delay={100}
              animateBy="letters"
              direction="top"
              className="landing-name landing-name-top"
              style={{ color: accentColor, fontFamily: 'Fira Code, monospace' }}
            />
            <BlurText
              text="KUMAR"
              delay={100}
              animateBy="letters"
              direction="top"
              className="landing-name landing-name-bottom"
              style={{ color: accentColor, fontFamily: 'Fira Code, monospace' }}
            />

            <div className="landing-profile-wrap">
              <div className="landing-profile">
                <img
                  src="https://i.postimg.cc/y8DnKLyK/albert-dera-ILip77-Sbm-OE-unsplash.jpg"
                  alt="Profile"
                  className="landing-profile-image"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="landing-tagline-wrap">
          <BlurText
            text="Designing human experiences in code."
            delay={150}
            animateBy="words"
            direction="top"
            className="landing-tagline"
            style={{ color: mutedAccentColor, fontFamily: 'Antic, sans-serif' }}
          />
        </div>

        <Link to="/home" className="landing-scroll-button" aria-label="Go to the Home page">
          <ChevronDown className="landing-scroll-icon" />
        </Link>
      </main>
    </div>
  );
}

export default LandingPage;