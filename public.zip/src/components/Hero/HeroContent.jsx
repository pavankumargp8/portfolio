import { motion } from "framer-motion";
import HeroButtons from "./HeroButtons";

export default function HeroContent() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: .8 }}
      className="flex flex-col justify-center"
    >
      <p className="tracking-[10px] text-cyan-400 uppercase text-sm">
        Pavan Kumar
      </p>

      <h1 className="mt-6 text-5xl font-bold leading-tight md:text-7xl">
        Building
        <br />
        Intelligent Software
        <br />
        <span className="text-slate-400">
          for the Modern Web.
        </span>
      </h1>

      <p className="mt-8 max-w-xl text-lg leading-8 text-slate-400">
        I build intelligent software that combines AI,
        automation, and modern web technologies to solve
        real-world problems.
      </p>

      <HeroButtons />
    </motion.div>
  );
}