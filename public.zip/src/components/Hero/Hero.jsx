import HeroContent from "./HeroContent";
import DeveloperConsole from "./DeveloperConsole";
import FloatingTech from "./FloatingTech";
import ScrollIndicator from "./ScrollIndicator";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      <div className="mx-auto grid w-full max-w-7xl grid-cols-1 gap-16 px-6 pt-28 pb-20 lg:grid-cols-2 lg:px-10">

        <HeroContent />

        <div className="relative flex items-center justify-center">
          <FloatingTech />
          <DeveloperConsole />
        </div>

      </div>

      <ScrollIndicator />
    </section>
  );
}