import Background from "./components/Background";
import ScrollProgress from "./components/ScrollProgress";

import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Education from "./components/Education";
import Achievements from "./components/Achievements";
import Footer from "./components/Footer";

function App() {
  return (
    <>
      
  <Loader />

  <Background />
  <GridBackground />
  <Spotlight />
  <ScrollProgress />

  <Navbar />

      <main className="relative z-10">
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Education />
        <Achievements />
        <Footer />
      </main>
    </>
  );
}

export default App;